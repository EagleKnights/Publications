#COMRob 2016
##Diseño y Desarrollo de un Robot Omnidireccional Enfocado en Robocup Small Size League

Proyect made with LaTex

- amrob.tex 	==>    the main LaTex file
- amrob.bib 	==>    for bibliografy
- Figures/    ==> 	dir where the images are
- amrob.pdf   ==>  	file generated with LaTex 


